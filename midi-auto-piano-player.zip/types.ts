
export interface PianoKeyInfo {
  midi: number;
  name: string; // e.g., "C4", "F#3"
  type: 'white' | 'black';
  offset: number; // For positioning black keys relative to white keys
}

export interface ParsedNote {
  midi: number;
  time: number; // in seconds, from start of track
  duration: number; // in seconds
  velocity: number; // 0-1
  name: string; // Note name like C4, F#3
}

export interface MidiTrack {
  name?: string;
  notes: ParsedNote[];
  duration: number;
}

export interface ParsedMidiData {
  header: {
    name?: string;
    tempos: unknown[]; // Simplified, actual tempo info is complex
    timeSignatures: unknown[]; // Simplified
  };
  tracks: MidiTrack[];
  duration: number; // Overall duration
}
    