
import React, { useCallback, useRef } from 'react';

interface FileUploaderProps {
  onFileChange: (file: File | null) => void;
  currentFileName: string | null;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ onFileChange, currentFileName }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null;
    onFileChange(file);
  }, [onFileChange]);

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="mb-6 p-4 border-2 border-dashed border-gray-600 rounded-lg hover:border-purple-500 transition-colors duration-200">
      <input
        type="file"
        accept=".mid,.midi"
        onChange={handleFileChange}
        ref={fileInputRef}
        className="hidden"
        id="midi-file-input"
      />
      <button
        onClick={handleButtonClick}
        className="w-full px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-md shadow-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-purple-400"
        aria-label="Upload MIDI file"
      >
        {currentFileName ? `Change File: ${currentFileName}` : 'Click to Upload MIDI File (.mid)'}
      </button>
      {currentFileName && (
         <p className="text-xs text-gray-400 mt-2 text-center">Currently loaded: {currentFileName}</p>
      )}
    </div>
  );
};
    