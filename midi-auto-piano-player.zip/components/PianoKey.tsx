import React from 'react';
import { PianoKeyInfo } from '../types';
import { WHITE_KEY_WIDTH_PERCENT, BLACK_KEY_WIDTH_PERCENT, BLACK_KEY_HEIGHT_PERCENT } from '../constants';

interface PianoKeyProps {
  keyInfo: PianoKeyInfo;
  isActive: boolean;
  isUpcoming: boolean;
  hitCount: number; // Thêm prop này
}

export const PianoKey: React.FC<PianoKeyProps> = React.memo(({ keyInfo, isActive, isUpcoming, hitCount }) => {
  const { type, name } = keyInfo;

  const baseClasses = "absolute border-gray-600 transition-all duration-50 ease-in-out transform";
  let specificClasses = "";
  let style: React.CSSProperties = {};

  if (type === 'white') {
    specificClasses = `h-full bg-gray-100 border-l ${isActive ? 'bg-purple-400 scale-95' : isUpcoming ? 'bg-blue-300' : 'hover:bg-gray-200'}`;
    style = {
      width: `${WHITE_KEY_WIDTH_PERCENT}%`,
      left: `${keyInfo.offset * WHITE_KEY_WIDTH_PERCENT}%`,
      zIndex: 1,
    };
  } else { // Black key
    specificClasses = `h-[${BLACK_KEY_HEIGHT_PERCENT}%] bg-gray-800 border ${isActive ? 'bg-pink-500 scale-95' : isUpcoming ? 'bg-indigo-400' : 'hover:bg-gray-700'}`;
    style = {
      width: `${BLACK_KEY_WIDTH_PERCENT}%`,
      left: `${(keyInfo.offset * WHITE_KEY_WIDTH_PERCENT) + (WHITE_KEY_WIDTH_PERCENT / 2) - (BLACK_KEY_WIDTH_PERCENT / 2)}%`,
      zIndex: 2,
    };
  }
  
  if (type === 'black') {
    style.height = `${BLACK_KEY_HEIGHT_PERCENT}%`;
  }

  const hitCountStyle: React.CSSProperties = {
    position: 'absolute',
    bottom: type === 'white' ? '4px' : '3px', // Điều chỉnh vị trí
    right: type === 'white' ? '4px' : '3px',  // Điều chỉnh vị trí
    fontSize: type === 'white' ? '8px' : '7px', // Giảm kích thước font
    color: type === 'white' ? 'rgba(0, 0, 0, 0.85)' : 'rgba(255, 255, 255, 0.85)', // Tăng độ rõ nét
    fontWeight: 'bold',
    pointerEvents: 'none',
    zIndex: 3,
    lineHeight: '1',
  };

  return (
    <div
      className={`${baseClasses} ${specificClasses}`}
      style={style}
      title={name}
      aria-label={`Piano key ${name}${hitCount > 0 ? `, hit ${hitCount} times` : ''}`}
    >
      {hitCount > 0 && (
        <span style={hitCountStyle}>
          {hitCount}
        </span>
      )}
    </div>
  );
});