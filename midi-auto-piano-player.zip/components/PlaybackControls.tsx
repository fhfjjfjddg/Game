
import React from 'react';

interface PlaybackControlsProps {
  onPlay: () => void;
  onPause: () => void;
  onStop: () => void;
  isPlaying: boolean;
  isReady: boolean;
  currentTime: number;
  duration: number;
  currentVolume: number; // Âm lượng hiện tại (0-100)
  onVolumeChange: (newVolume: number) => void; // Callback khi âm lượng thay đổi
}

const PlayIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" height="1em" width="1em" {...props}><path d="M8 5v14l11-7z" /></svg>
);

const PauseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" height="1em" width="1em" {...props}><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
);

const StopIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" height="1em" width="1em" {...props}><path d="M6 6h12v12H6z" /></svg>
);

const VolumeHighIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" height="1em" width="1em" {...props}>
    <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" />
  </svg>
);

const VolumeOffIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
 <svg viewBox="0 0 24 24" fill="currentColor" height="1em" width="1em" {...props}>
    <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
  </svg>
);


export const PlaybackControls: React.FC<PlaybackControlsProps> = ({
  onPlay,
  onPause,
  onStop,
  isPlaying,
  isReady,
  currentTime,
  duration,
  currentVolume,
  onVolumeChange,
}) => {
  const formatTime = (timeInSeconds: number): string => {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  const progressPercentage = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="my-6 flex flex-col items-center space-y-4">
      <div className="flex space-x-4 items-center">
        <button
          onClick={isPlaying ? onPause : onPlay}
          disabled={!isReady}
          className={`p-3 rounded-full transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-opacity-50 ${
            isReady
              ? 'bg-purple-600 hover:bg-purple-700 text-white focus:ring-purple-400'
              : 'bg-gray-600 text-gray-400 cursor-not-allowed'
          }`}
          aria-label={isPlaying ? 'Tạm dừng' : 'Phát'}
        >
          {isPlaying ? <PauseIcon className="w-6 h-6" /> : <PlayIcon className="w-6 h-6" />}
        </button>
        <button
          onClick={onStop}
          disabled={!isReady}
          className={`p-3 rounded-full transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-opacity-50 ${
            isReady
              ? 'bg-red-600 hover:bg-red-700 text-white focus:ring-red-400'
              : 'bg-gray-600 text-gray-400 cursor-not-allowed'
          }`}
          aria-label="Dừng"
        >
          <StopIcon className="w-6 h-6" />
        </button>
      </div>

      {/* Thanh trượt âm lượng */}
      {isReady && (
        <div className="w-full max-w-xs flex items-center space-x-3 pt-2 px-2">
          {currentVolume === 0 ? <VolumeOffIcon className="w-5 h-5 text-gray-400" /> : <VolumeHighIcon className="w-5 h-5 text-gray-400" /> }
          <input
            id="volume-slider"
            type="range"
            min="0"
            max="100"
            value={currentVolume}
            onChange={(e) => onVolumeChange(parseInt(e.target.value, 10))}
            disabled={!isReady}
            className={`w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-pink-500 transition-opacity duration-150 ${
              !isReady ? 'opacity-50 cursor-not-allowed' : ''
            }`}
            aria-label="Điều chỉnh âm lượng"
          />
          <span className="text-sm text-gray-300 w-10 text-right tabular-nums">{currentVolume}%</span>
        </div>
      )}

      {isReady && (
        <div className="w-full max-w-md pt-2">
          <div className="relative h-2 bg-gray-700 rounded-full">
            <div
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-100 ease-linear"
              style={{ width: `${progressPercentage}%` }}
              aria-valuenow={progressPercentage}
              aria-valuemin={0}
              aria-valuemax={100}
              role="progressbar"
              aria-label="Tiến độ phát nhạc"
            />
          </div>
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>
      )}
    </div>
  );
};
