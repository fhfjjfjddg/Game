
import React from 'react';
import { PianoKey } from './PianoKey';
import { PIANO_KEYS_CONFIG, VISUAL_KEYBOARD_START_MIDI, VISUAL_KEYBOARD_END_MIDI } from '../constants';
import { ParsedNote } from '../types';

interface PianoKeyboardProps {
  activeNotes: Set<number>; 
  allNotes: ParsedNote[]; 
  currentTime: number;
  noteHitCounts: Map<number, number>; // Thêm prop này
}

export const PianoKeyboard: React.FC<PianoKeyboardProps> = ({ activeNotes, allNotes, currentTime, noteHitCounts }) => {
  const upcomingNotes = React.useMemo(() => {
    const lookAheadTime = 0.5; 
    const upcoming = new Set<number>();
    if (allNotes) {
        for (const note of allNotes) {
            if (note.time > currentTime && note.time <= currentTime + lookAheadTime) {
                if (note.midi >= VISUAL_KEYBOARD_START_MIDI && note.midi <= VISUAL_KEYBOARD_END_MIDI) {
                    upcoming.add(note.midi);
                }
            }
        }
    }
    return upcoming;
  }, [allNotes, currentTime]);

  return (
    <div className="relative w-full h-full bg-gray-800 rounded-md overflow-hidden shadow-lg">
      {PIANO_KEYS_CONFIG.map((keyInfo) => (
        <PianoKey
          key={keyInfo.midi}
          keyInfo={keyInfo}
          isActive={activeNotes.has(keyInfo.midi)}
          isUpcoming={upcomingNotes.has(keyInfo.midi)}
          hitCount={noteHitCounts.get(keyInfo.midi) || 0} // Truyền số lần nhấn
        />
      ))}
    </div>
  );
};
