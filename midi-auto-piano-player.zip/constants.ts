
import { PianoKeyInfo } from './types';

export const VISUAL_KEYBOARD_START_MIDI = 36; // C2
export const VISUAL_KEYBOARD_END_MIDI = 84;   // C6
export const NUM_VISUAL_KEYS = VISUAL_KEYBOARD_END_MIDI - VISUAL_KEYBOARD_START_MIDI + 1; // 49 keys (4 octaves C2-C6)

const NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

export const midiToNoteName = (midiNumber: number): string => {
  if (midiNumber < 0 || midiNumber > 127) {
    return "Invalid MIDI note";
  }
  const octave = Math.floor(midiNumber / 12) - 1;
  const noteIndex = midiNumber % 12;
  return NOTE_NAMES[noteIndex] + octave;
};

export const getPianoKeys = (startNote: number, endNote: number): PianoKeyInfo[] => {
  const keys: PianoKeyInfo[] = [];
  let whiteKeyCounter = 0;
  for (let midi = startNote; midi <= endNote; midi++) {
    const noteName = midiToNoteName(midi);
    const noteIndexInOctave = midi % 12;
    const isBlackKey = [1, 3, 6, 8, 10].includes(noteIndexInOctave);
    
    let offset = 0;
    if (!isBlackKey) {
      whiteKeyCounter++;
    } else {
      // Calculate offset for black keys based on previous white key
      // This is a simplified offset logic
      offset = whiteKeyCounter - 0.5; 
    }

    keys.push({
      midi: midi,
      name: noteName,
      type: isBlackKey ? 'black' : 'white',
      offset: isBlackKey ? offset : whiteKeyCounter -1, // white keys are sequential
    });
  }
  return keys;
};

export const PIANO_KEYS_CONFIG: PianoKeyInfo[] = getPianoKeys(VISUAL_KEYBOARD_START_MIDI, VISUAL_KEYBOARD_END_MIDI);

export const WHITE_KEY_WIDTH_PERCENT = 100 / PIANO_KEYS_CONFIG.filter(k => k.type === 'white').length;
export const BLACK_KEY_WIDTH_PERCENT = WHITE_KEY_WIDTH_PERCENT * 0.6;
export const BLACK_KEY_HEIGHT_PERCENT = 60; // % of white key height
    