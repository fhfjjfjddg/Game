
import { useState, useEffect, useCallback, useRef } from 'react';
import * as Tone from 'tone';
import { Midi } from '@tonejs/midi';
import { ParsedMidiData, ParsedNote, MidiTrack } from '../types';
import { midiToNoteName } from '../constants';

// Helper to convert percentage to dB for Tone.js
// 0% = -Infinity dB (mute), 100% = 0 dB (original volume)
const percentageToDb = (percentage: number): number => {
  if (percentage === 0) return -Infinity;
  // Sử dụng hàm mũ để gain tăng nhanh hơn ở mức % cao hơn
  // Ví dụ: (percentage / 100)^2. Điều này làm cho 100% vẫn là 0dB (gain 1),
  // nhưng 75% sẽ có gain là (0.75)^2 = 0.5625 (khoảng -5dB),
  // và 50% sẽ có gain là (0.5)^2 = 0.25 (khoảng -12dB).
  // Điều này tạo ra sự khác biệt lớn hơn ở các mức âm lượng cao.
  const gain = Math.pow(percentage / 100, 2);
  return Tone.gainToDb(gain);
};

export const useMidiPlayer = (midiFile: File | null) => {
  const [parsedMidiData, setParsedMidiData] = useState<ParsedMidiData | null>(null);
  const [activeNotes, setActiveNotes] = useState<Set<number>>(new Set());
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isAudioReady, setIsAudioReady] = useState(false);
  const [noteHitCounts, setNoteHitCounts] = useState<Map<number, number>>(new Map());
  const [volume, setVolume] = useState<number>(75); // Âm lượng từ 0-100


  const synthRef = useRef<Tone.PolySynth | null>(null);
  const limiterRef = useRef<Tone.Limiter | null>(null);
  const tonePartRef = useRef<Tone.Part | null>(null);
  const scheduledEventsRef = useRef<Map<string, number[]>>(new Map());


  const initAudio = useCallback(async () => {
    console.log("[useMidiPlayer] initAudio called.");
    setError(null); 

    if ((Tone.context.state as AudioContextState) === 'suspended') {
      try {
        await Tone.start();
        const updatedContextState: AudioContextState = Tone.context.state;
        console.log("[useMidiPlayer] Tone.start() executed, context state:", updatedContextState);
        if (updatedContextState !== 'running') {
          const errMsg = "Audio context failed to start. Please interact with the page or check browser permissions.";
          console.error("[useMidiPlayer]", errMsg, "State:", updatedContextState);
          setError(errMsg);
          setIsAudioReady(false);
          return;
        }
      } catch (err) {
        const errMsg = "Error starting audio engine.";
        console.error("[useMidiPlayer]", errMsg, err);
        setError(errMsg + (err instanceof Error ? ` ${err.message}` : ''));
        setIsAudioReady(false);
        return;
      }
    }

    if (!limiterRef.current) {
        try {
            limiterRef.current = new Tone.Limiter(-6).toDestination();
            console.log("[useMidiPlayer] Limiter created.");
        } catch (err) {
            const errMsg = "Failed to create audio limiter.";
            console.error("[useMidiPlayer]", errMsg, err);
            setError(errMsg + (err instanceof Error ? ` ${err.message}` : ''));
            setIsAudioReady(false);
            return;
        }
    }

    if (!synthRef.current && limiterRef.current) {
      try {
        const initialDbVolume = percentageToDb(volume);
        synthRef.current = new Tone.PolySynth({
            maxPolyphony: 24, 
            voice: Tone.Synth,
            options: { 
                oscillator: { type: 'triangle' },
                envelope: { attack: 0.01, decay: 0.1, sustain: 0.3, release: 0.25 }, 
                volume: -15, // Âm lượng của từng voice riêng lẻ
            },
            volume: initialDbVolume, // Âm lượng tổng thể của PolySynth
        }).connect(limiterRef.current);
        console.log(`[useMidiPlayer] PolySynth created. Initial master volume: ${volume}% (${initialDbVolume.toFixed(1)}dB)`);
        
        (Tone.Transport as any).lookAhead = 0.15; 
        console.log("[useMidiPlayer] Tone.Transport.lookAhead set to 0.15s.");

      } catch (err) {
        const errMsg = "Failed to create synthesizer.";
        console.error("[useMidiPlayer]", errMsg, err);
        setError(errMsg + (err instanceof Error ? ` ${err.message}` : ''));
        setIsAudioReady(false);
        return;
      }
    } else if (synthRef.current) {
      // Nếu synth đã tồn tại, đảm bảo âm lượng của nó khớp với trạng thái volume hiện tại
      const currentDbVolume = percentageToDb(volume);
      synthRef.current.volume.value = currentDbVolume;
      console.log(`[useMidiPlayer] Synth already exists. Synced master volume to: ${volume}% (${currentDbVolume.toFixed(1)}dB)`);
    }


    if (!limiterRef.current || !synthRef.current) {
        const errMsg = "Audio components (limiter or synth) failed to initialize properly.";
        console.error("[useMidiPlayer]", errMsg);
        setError(errMsg);
        setIsAudioReady(false);
        return;
    }

    setIsAudioReady(true); 
    console.log('[useMidiPlayer] Audio engine initialized successfully, isAudioReady set to true.');
  }, [setError, volume]); // Thêm volume vào dependency array


  const stop = useCallback(() => {
    console.log("[useMidiPlayer] stop function called.");
    Tone.Transport.stop();
    console.log("[useMidiPlayer] Tone.Transport.stop() called.");
    
    if (synthRef.current) {
        synthRef.current.releaseAll(); 
        console.log("[useMidiPlayer] synthRef.current.releaseAll() called.");
    }

    if (tonePartRef.current) {
        console.log("[useMidiPlayer] Clearing and stopping tonePartRef.current.");
        tonePartRef.current.stop(0); 
        tonePartRef.current.clear(); 
    }
    
    Tone.Transport.cancel(); 
    Tone.Transport.position = 0; 
    console.log("[useMidiPlayer] Tone.Transport cancelled and position reset.");
    
    setCurrentTime(0);
    setIsPlaying(false);
    setActiveNotes(new Set()); 
    setNoteHitCounts(new Map()); 
    
    scheduledEventsRef.current.forEach(timeoutIds => timeoutIds.forEach(clearTimeout));
    scheduledEventsRef.current.clear();
    console.log("[useMidiPlayer] Playback state reset.");
  }, []); 


  useEffect(() => {
    if (!midiFile) {
      console.log("[useMidiPlayer] midiFile is null, stopping playback and clearing data.");
      stop(); 
      setParsedMidiData(null);
      setError(null); 
      setDuration(0);
      setCurrentTime(0); 
      return;
    }

    const parseFile = async () => {
      console.log("[useMidiPlayer] Starting to parse new MIDI file:", midiFile.name);
      setIsLoading(true);
      setError(null); 
      
      console.log("[useMidiPlayer] New file detected, stopping existing playback before parsing.");
      stop(); 

      try {
        const arrayBuffer = await midiFile.arrayBuffer();
        const midi = new Midi(arrayBuffer);
        console.log("[useMidiPlayer] MIDI file parsed with @tonejs/midi.");

        if (midi.header.tempos && midi.header.tempos.length > 0) {
            const primaryTempo = midi.header.tempos.find(t => (t as any).bpm);
            if (primaryTempo && (primaryTempo as any).bpm) {
                Tone.Transport.bpm.value = (primaryTempo as any).bpm;
            } else {
                Tone.Transport.bpm.value = 120; 
            }
        } else {
            Tone.Transport.bpm.value = 120;
        }
        console.log("[useMidiPlayer] Tone.Transport.bpm set to:", Tone.Transport.bpm.value);
        
        const tracks: MidiTrack[] = midi.tracks.map(track => ({
          name: track.name,
          notes: track.notes.map(note => ({
            midi: note.midi,
            time: note.time,
            duration: note.duration,
            velocity: note.velocity,
            name: midiToNoteName(note.midi),
          })),
          duration: track.duration,
        }));
        
        const mainTrack = tracks.find(t => t.notes.length > 0) || (tracks.length > 0 ? tracks[0] : null);
        const trackDuration = mainTrack ? mainTrack.duration : midi.duration;
        console.log(`[useMidiPlayer] Parsed MIDI data. Duration: ${trackDuration}s. Tracks: ${tracks.length}`);

        setParsedMidiData({
          header: { name: midi.header.name, tempos: midi.header.tempos, timeSignatures: midi.header.timeSignatures },
          tracks: tracks,
          duration: trackDuration,
        });
        setDuration(trackDuration);
        setCurrentTime(0); 

      } catch (e) {
        console.error("[useMidiPlayer] Error parsing MIDI file:", e);
        const errMsg = "Failed to parse MIDI file. It might be corrupted or not a valid MIDI format.";
        setError(errMsg + (e instanceof Error ? ` ${e.message}` : ''));
        setParsedMidiData(null);
        setDuration(0);
        setCurrentTime(0);
      } finally {
        setIsLoading(false);
        console.log("[useMidiPlayer] MIDI file processing finished.");
      }
    };

    parseFile();
    
    return () => { 
        console.log("[useMidiPlayer] useEffect midiFile cleanup: midiFile changed or component unmounted.");
        if (tonePartRef.current) {
            console.log("[useMidiPlayer] useEffect midiFile cleanup: Disposing existing tonePartRef if file changes.");
            tonePartRef.current.stop(0);
            tonePartRef.current.clear();
            tonePartRef.current.dispose(); 
            tonePartRef.current = null;
        }
    };
  }, [midiFile, stop, setError]);


  const play = useCallback(() => {
    console.log("%c[useMidiPlayer] Play function called.", "color: #007bff; font-weight: bold;");
    if (!isAudioReady) {
        const errMsg = "Audio engine not ready. Please click 'Initialize Audio Engine' or interact again.";
        console.warn("[useMidiPlayer] Play aborted: Audio not ready.", errMsg);
        setError(errMsg);
        return;
    }
    if (!synthRef.current) {
        const errMsg = "Synthesizer not initialized. Please try re-initializing audio.";
        console.error("[useMidiPlayer] Play aborted:", errMsg);
        setError(errMsg);
        return;
    }
    if (!parsedMidiData) {
        const errMsg = "No MIDI data loaded. Please upload a MIDI file.";
        console.warn("[useMidiPlayer] Play aborted:", errMsg);
        setError(errMsg);
        return;
    }
    console.log("[useMidiPlayer] Play pre-conditions met: Audio ready, synth initialized, MIDI data loaded.");

    const playbackTrack = parsedMidiData.tracks.find(t => t.notes.length > 0);
    if (!playbackTrack || playbackTrack.notes.length === 0) {
        const errMsg = "No playable notes found in the MIDI file.";
        console.warn("[useMidiPlayer] Play aborted:", errMsg);
        setError(errMsg);
        return;
    }
    console.log(`[useMidiPlayer] Selected track for playback: '${playbackTrack.name || 'Untitled'}', Notes: ${playbackTrack.notes.length}`);
    if (playbackTrack.notes.length > 0) {
        console.log("[useMidiPlayer] First 3 notes of playbackTrack:", playbackTrack.notes.slice(0, 3));
    }
    
    console.log("[useMidiPlayer] Preparing for new playback: stopping transport and cleaning up old part.");
    Tone.Transport.stop(); 
    Tone.Transport.cancel();
    if (tonePartRef.current) {
      console.log("[useMidiPlayer] Disposing existing Tone.Part before creating a new one.");
      tonePartRef.current.stop(0);
      tonePartRef.current.clear();
      tonePartRef.current.dispose();
      tonePartRef.current = null;
    }
    synthRef.current.releaseAll(); 
    Tone.Transport.position = 0; 
    
    setCurrentTime(0);
    setActiveNotes(new Set());
    setNoteHitCounts(new Map()); 
    scheduledEventsRef.current.forEach(timeoutIds => timeoutIds.forEach(clearTimeout));
    scheduledEventsRef.current.clear();
    console.log("[useMidiPlayer] UI state (currentTime, activeNotes, noteHitCounts) reset for new playback.");

    tonePartRef.current = new Tone.Part<ParsedNote>((time, note) => {
      if (synthRef.current && note.name && note.duration > 0) { 
        synthRef.current.triggerAttackRelease(note.name, note.duration, time, note.velocity);
      } else {
        console.warn(`[useMidiPlayer] Synth trigger skipped: synth=${!!synthRef.current}, name=${note.name}, dur=${note.duration}`);
      }
      
      setActiveNotes(prev => new Set(prev).add(note.midi));
      setNoteHitCounts(prevCounts => {
        const newCounts = new Map(prevCounts);
        newCounts.set(note.midi, (newCounts.get(note.midi) || 0) + 1);
        return newCounts;
      });
      
      const timeoutId = window.setTimeout(() => {
        setActiveNotes(prev => {
          const next = new Set(prev);
          next.delete(note.midi);
          return next;
        });
        const eventKey = `${time}-${note.midi}`;
        const timeouts = scheduledEventsRef.current.get(eventKey);
        if (timeouts) {
            const index = timeouts.indexOf(timeoutId);
            if (index > -1) timeouts.splice(index, 1);
            if (timeouts.length === 0) scheduledEventsRef.current.delete(eventKey);
        }

      }, note.duration * 1000); 

      const eventKey = `${time}-${note.midi}`;
      const existingTimeouts = scheduledEventsRef.current.get(eventKey) || [];
      scheduledEventsRef.current.set(eventKey, [...existingTimeouts, timeoutId]);

    }, playbackTrack.notes); 
    
    console.log("[useMidiPlayer] New Tone.Part created with notes. Starting part at time 0 relative to transport.");
    tonePartRef.current.loop = false; 
    tonePartRef.current.start(0); 
    
    console.log("[useMidiPlayer] Current Tone.Transport.state before start:", Tone.Transport.state);
    Tone.Transport.start("+0.1"); 
    console.log("[useMidiPlayer] Tone.Transport.start('+0.1') called.");

    Tone.Transport.scheduleOnce(() => {
        console.log(`%c[useMidiPlayer] Tone.Transport scheduled confirmation: State = ${Tone.Transport.state}, Current Time (seconds) = ${Tone.Transport.seconds.toFixed(3)}`, "color: #17a2b8; font-weight: bold;");
    }, "+0.15"); 

    setIsPlaying(true);
    console.log("%c[useMidiPlayer] Playback initiated, isPlaying set to true.", "color: #007bff; font-weight: bold;");

  }, [parsedMidiData, isAudioReady, setError]); 

  const pause = useCallback(() => {
    console.log("[useMidiPlayer] pause function called.");
    if (!isAudioReady || !isPlaying) {
        console.log(`[useMidiPlayer] Pause aborted: isAudioReady=${isAudioReady}, isPlaying=${isPlaying}`);
        return;
    }
    Tone.Transport.pause();
    setIsPlaying(false);
    if (synthRef.current) { 
        synthRef.current.releaseAll();
    }
    console.log("[useMidiPlayer] Tone.Transport.pause() called, isPlaying set to false, synth released.");
  }, [isAudioReady, isPlaying]);

  const handleVolumeChange = useCallback((newVolumePercent: number) => {
    const newVolume = Math.max(0, Math.min(100, newVolumePercent)); // Đảm bảo giá trị trong khoảng 0-100
    setVolume(newVolume);
    if (synthRef.current) {
        const db = percentageToDb(newVolume);
        synthRef.current.volume.value = db;
        console.log(`[useMidiPlayer] Master volume changed to ${newVolume}%, ${db.toFixed(1)}dB`);
    }
  }, []); // synthRef là một ref, không cần đưa vào dependency array vì object ref ổn định


  useEffect(() => {
    let animationFrameId: number;
    const update = () => {
      if (isPlaying && Tone.Transport.state === "started") {
        setCurrentTime(Tone.Transport.seconds);
      }
      animationFrameId = requestAnimationFrame(update);
    };
    animationFrameId = requestAnimationFrame(update);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying]); 

  useEffect(() => {
    return () => {
      console.log("[useMidiPlayer] Main unmount cleanup effect running.");
      stop(); 
      
      if (tonePartRef.current) { 
        console.log("[useMidiPlayer] Unmount: Disposing tonePartRef.");
        tonePartRef.current.dispose();
        tonePartRef.current = null;
      }
      if (synthRef.current) {
        console.log("[useMidiPlayer] Unmount: Disposing synthRef.");
        synthRef.current.dispose();
        synthRef.current = null;
      }
      if (limiterRef.current) {
        console.log("[useMidiPlayer] Unmount: Disposing limiterRef.");
        limiterRef.current.dispose();
        limiterRef.current = null;
      }
      console.log("[useMidiPlayer] Unmount: Audio resources disposed.");
    };
  }, [stop]); 
  
   useEffect(() => {
    const resumeAudioContext = async () => {
      if ((Tone.context.state as AudioContextState) === 'suspended') {
        console.log("[useMidiPlayer] AudioContext state is", Tone.context.state, ". Attempting to resume via Tone.start().");
        await Tone.start();
        const newContextState: AudioContextState = Tone.context.state;
        if (newContextState === 'running') {
            console.log('[useMidiPlayer] AudioContext resumed by event listener or already running.');
        } else {
            console.warn('[useMidiPlayer] AudioContext could not be set to running via event. Current state:', newContextState);
        }
      }
    };

    const context = Tone.getContext();
    if (context) {
        context.on('statechange', resumeAudioContext);
        console.log("[useMidiPlayer] Attached Tone.context 'statechange' listener.");
    }
    
    document.addEventListener('visibilitychange', resumeAudioContext);
    console.log("[useMidiPlayer] Attached 'visibilitychange' listener for audio context resumption.");

    return () => {
      if (context) {
        context.off('statechange', resumeAudioContext);
        console.log("[useMidiPlayer] Removed Tone.context 'statechange' listener.");
      }
      document.removeEventListener('visibilitychange', resumeAudioContext);
      console.log("[useMidiPlayer] Removed 'visibilitychange' listener.");
    };
  }, []); 


  return {
    parsedMidiData,
    activeNotes,
    isPlaying,
    isLoading,
    error,
    play,
    pause,
    stop,
    duration,
    currentTime,
    initAudio,
    isAudioReady,
    noteHitCounts,
    volume, // Trả về trạng thái âm lượng
    handleVolumeChange, // Trả về hàm xử lý thay đổi âm lượng
  };
};
