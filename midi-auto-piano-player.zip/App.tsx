
import React, { useState, useCallback, useEffect } from 'react';
import { FileUploader } from './components/FileUploader';
import { PianoKeyboard } from './components/PianoKeyboard';
import { PlaybackControls } from './components/PlaybackControls';
import { LoadingSpinner } from './components/LoadingSpinner';
import { useMidiPlayer } from './hooks/useMidiPlayer';
import { ParsedMidiData } from './types'; 

const App: React.FC = () => {
  const [midiFile, setMidiFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string>('');

  const {
    parsedMidiData,
    activeNotes,
    isPlaying,
    isLoading,
    error,
    play,
    pause,
    stop,
    duration,
    currentTime,
    initAudio,
    isAudioReady,
    noteHitCounts,
    volume, // Nhận trạng thái âm lượng
    handleVolumeChange, // Nhận hàm xử lý thay đổi âm lượng
  } = useMidiPlayer(midiFile);

  const handleFileChangeCallback = useCallback((file: File | null) => {
    setMidiFile(file);
    setFileName(file ? file.name : '');
  }, []);

  const handlePlay = useCallback(async () => {
    let audioJustInitialized = false;
    if (!isAudioReady) {
      await initAudio();
      audioJustInitialized = true; 
    }
    
    // Cần kiểm tra isAudioReady LẠI SAU KHI initAudio có thể đã chạy
    // Nếu isAudioReady từ hook đã được cập nhật thành true thì sử dụng nó
    // Hoặc, nếu initAudio vừa chạy, nó sẽ tự set isAudioReady.
    // Logic này phức tạp do tính bất đồng bộ.
    // Đơn giản hơn: useMidiPlayer hook quản lý isAudioReady.
    // Chúng ta chỉ cần gọi play() nếu các điều kiện được đáp ứng.
    // play() bên trong hook sẽ tự kiểm tra isAudioReady.

    if (parsedMidiData) { // Chỉ cần kiểm tra parsedMidiData, play() sẽ lo phần còn lại
        play();
    } else if (!parsedMidiData) {
        console.warn("App: Play clicked, but no MIDI data is loaded.");
    }
  }, [isAudioReady, initAudio, parsedMidiData, play]); // Giữ isAudioReady để re-render khi nó thay đổi

  useEffect(() => {
    if (midiFile) {
        // useMidiPlayer hook đã xử lý việc stop khi file thay đổi.
    }
  }, [midiFile]); 

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4 sm:p-8">
      <header className="w-full max-w-4xl mb-8 text-center">
        <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">
          MIDI Auto Piano
        </h1>
        <p className="text-gray-400 mt-2 text-sm sm:text-base">
          Tải lên file .mid và xem điều kỳ diệu diễn ra trên các phím đàn!
        </p>
      </header>

      <main className="w-full max-w-4xl bg-gray-800 shadow-2xl rounded-lg p-6 sm:p-8">
        <FileUploader onFileChange={handleFileChangeCallback} currentFileName={fileName} />

        {isLoading && (
          <div className="my-6 flex flex-col items-center justify-center text-purple-400">
            <LoadingSpinner />
            <p className="mt-2">Đang xử lý file MIDI...</p>
          </div>
        )}

        {error && (
          <div className="my-6 p-4 bg-red-700 text-red-100 rounded-md text-center">
            <p className="font-semibold">Lỗi:</p>
            <p>{error}</p>
          </div>
        )}

        {!isAudioReady && midiFile && !isLoading && !error && (
           <div className="my-6 text-center">
             <button
                onClick={initAudio} 
                className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg shadow-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-green-400"
              >
                Khởi tạo Audio Engine
              </button>
              <p className="text-sm text-gray-400 mt-2">Audio cần được khởi tạo bởi tương tác người dùng để bắt đầu phát.</p>
           </div>
        )}

        {parsedMidiData && isAudioReady && !isLoading && !error && (
          <>
            <div className="my-6 text-center">
              <h2 className="text-xl font-semibold text-purple-300">
                Đã tải: {parsedMidiData.header.name || fileName || 'Bản nhạc MIDI'}
              </h2>
              {parsedMidiData.tracks.length > 0 && (
                <p className="text-sm text-gray-400">
                  Thời lượng: {Math.round(duration)}giây
                  {parsedMidiData.tracks[0]?.name ? ` | Track: ${parsedMidiData.tracks[0].name}` : ''}
                </p>
              )}
            </div>

            <PlaybackControls
              onPlay={handlePlay}
              onPause={pause}
              onStop={stop}
              isPlaying={isPlaying}
              isReady={!!parsedMidiData && isAudioReady} 
              currentTime={currentTime}
              duration={duration}
              currentVolume={volume} // Truyền âm lượng hiện tại
              onVolumeChange={handleVolumeChange} // Truyền hàm xử lý thay đổi âm lượng
            />
            
            <div className="mt-8 mb-4 relative h-48 sm:h-64 w-full overflow-hidden rounded-md shadow-inner bg-gray-700 p-2">
               <PianoKeyboard 
                 activeNotes={activeNotes} 
                 allNotes={parsedMidiData.tracks.find(t => t.notes.length > 0)?.notes || []} 
                 currentTime={currentTime} 
                 noteHitCounts={noteHitCounts}
                />
            </div>
          </>
        )}
        
        {!midiFile && !isLoading && !error && (
            <div className="my-10 text-center text-gray-500">
                <p className="text-lg">Vui lòng tải lên một file MIDI để bắt đầu.</p>
            </div>
        )}
      </main>

      <footer className="w-full max-w-4xl mt-12 text-center text-gray-500 text-sm">
        <p>&copy; {new Date().getFullYear()} MIDI Auto Piano. Phát triển bởi Huy Gia &amp; Gemini. Ý tưởng: Huy Gia. Review: Huy Gia. Lập trình: Gemini. Sửa mã: Gemini.</p>
      </footer>
    </div>
  );
};

export default App;
